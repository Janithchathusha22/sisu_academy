import frappe
from frappe.utils import today, getdate, now_datetime
from .domain import billing_total
from .api import identity, require_role


def daily():
    frappe.db.sql("UPDATE `tabIL Invoice` SET status='Overdue' WHERE status='Unpaid' AND due_date < %s", (today(),))
    current = getdate(today())
    for inst in frappe.get_all("IL Institute", fields=["name", "base_fee", "billing_day"]):
        # Monthly active-membership snapshot. A student is counted once, regardless of class count.
        if current.day < max(1, min(inst.billing_day or 1, 28)):
            continue
        period = current.strftime("%Y-%m")
        if frappe.db.exists("IL Institute Bill", {"institute": inst.name, "period": period}):
            continue
        count = frappe.db.count("IL Member", {"institute": inst.name, "role": "Student", "active": 1})
        frappe.get_doc({"doctype": "IL Institute Bill", "institute": inst.name, "period": period,
            "active_students": count, "included_students": 500, "extra_students": max(0, count - 500),
            "unit_rate": 50, "base_fee": inst.base_fee, "total": billing_total(count, inst.base_fee), "status": "Unpaid"}).insert(ignore_permissions=True)


@frappe.whitelist()
def summary():
    inst, member = identity()
    require_role(member, "Admin")
    count = frappe.db.count("IL Member", {"institute": inst.name, "role": "Student", "active": 1})
    return {"active_students": count, "included": 500, "extra_students": max(0, count-500),
        "base_fee": inst.base_fee, "extra_fee": max(0, count-500)*50, "total": billing_total(count, inst.base_fee),
        "history": frappe.get_all("IL Institute Bill", filters={"institute": inst.name}, fields=["*"], limit_page_length=24, order_by="period desc")}
