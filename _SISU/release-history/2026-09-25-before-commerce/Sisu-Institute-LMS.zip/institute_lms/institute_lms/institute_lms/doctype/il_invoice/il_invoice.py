from frappe.model.document import Document


class ILInvoice(Document):
    pass
