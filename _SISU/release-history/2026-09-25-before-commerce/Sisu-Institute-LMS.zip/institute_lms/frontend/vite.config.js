import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
export default defineConfig(({ command }) => ({
  plugins: [vue()],
  base: command === 'build' ? '/assets/institute_lms/portal/' : '/',
  build: { outDir: '../institute_lms/public/portal', emptyOutDir: true },
  server: { port: 5178, strictPort: true },
}))
