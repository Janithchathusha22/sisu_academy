"""Freeze beneficiary and platform fees before an invoice starts checkout."""
from decimal import Decimal
import frappe
from .wallet import usd_lkr_minor
from .wallet_rules import minor

def invoice_split(institute,class_amount):
    # Existing portal classrooms belong to their institute. Do not credit teachers
    # individually for these classes; independent courses need their own wallet.
    if institute.get('school_mode'):return None
    if not frappe.conf.get('il_class_platform_fee_enabled'):
        return {'amount':class_amount}  # Existing contracts retain their original price.
    wallets=frappe.get_all('IL Wallet',filters={'institute':institute.name,'beneficiary':'Institute','currency':'LKR','enabled':1},pluck='name',limit_page_length=2)
    if len(wallets)!=1:frappe.throw('Finance must configure one institute settlement wallet')
    fee=usd_lkr_minor(1);earned=minor(class_amount)
    return {'amount':Decimal(earned+fee)/100,'currency':'LKR','payout_wallet':wallets[0],'beneficiary_minor':earned,'platform_minor':fee}
