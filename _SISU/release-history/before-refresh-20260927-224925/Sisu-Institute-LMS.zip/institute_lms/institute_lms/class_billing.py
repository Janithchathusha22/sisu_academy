"""Freeze beneficiary and platform fees before an invoice starts checkout."""
from decimal import Decimal
import frappe
from .wallet_rules import minor

def invoice_split(institute,class_amount,student_user=None):
    # Existing portal classrooms belong to their institute. Do not credit teachers
    # individually for these classes; independent courses need their own wallet.
    if institute.get('school_mode'):return None
    from .owner_pricing import current,amount
    if not student_user:frappe.throw('A student price assignment is required')
    contract=current(student_user,'Class payment')
    if contract.currency!='LKR' or contract.period!='Per payment':frappe.throw('This classroom requires an LKR per-payment assignment')
    wallets=frappe.get_all('IL Wallet',filters={'institute':institute.name,'beneficiary':'Institute','currency':'LKR','enabled':1},pluck='name',limit_page_length=2)
    if len(wallets)!=1:frappe.throw('Finance must configure one institute settlement wallet')
    fee=amount(contract)['total_minor'];earned=minor(class_amount)
    return {'amount':Decimal(earned+fee)/100,'currency':'LKR','payout_wallet':wallets[0],'beneficiary_minor':earned,'platform_minor':fee,'pricing_assignment':contract.name}
