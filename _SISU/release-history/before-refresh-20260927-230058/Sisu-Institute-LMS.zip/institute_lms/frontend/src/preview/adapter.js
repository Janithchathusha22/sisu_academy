// Local interaction sandbox. No credentials, seeded students or provider calls.
const roles={Student:{name:'preview-student',role:'Student',full_name:'Student preview',user:'student@admin.com'},Teacher:{name:'preview-teacher',role:'Teacher',full_name:'Teacher preview',user:'teacher@admin.com'},Admin:{name:'preview-institute',role:'Admin',full_name:'Institute preview',user:'institute@admin.com'}}
let role='Student'
const initial=()=>({institute:{name:'preview-workspace',title:'Your institute',code:'PREVIEW',language:'en',accent:'#9874ba'},rooms:[],sessions:[],news:[],invoices:[],notifications:[],papers:[],attempts:[],profiles:[],links:[],assignments:[],tickets:[],replies:[],attendance:[],grants:[]})
let db=initial()
try{const saved=JSON.parse(sessionStorage.getItem('sisu-interface-preview-v1'));if(saved?.version===1)db=saved.data}catch{}
const persist=()=>sessionStorage.setItem('sisu-interface-preview-v1',JSON.stringify({version:1,data:db}))
const id=prefix=>prefix+'-'+crypto.randomUUID().slice(0,8)
const own=()=>roles[role]||{name:'preview-owner',role:'PlatformAdmin',full_name:'Owner preview',user:'superadmin@admin.com'}
const blankMoney={classrooms:0,paid_total:0,outstanding_total:0,paid_count:0,unpaid_count:0}
export function selectPreviewRole(value){if(!['Student','Teacher','Admin','Super Admin'].includes(value))throw Error('Unknown preview role');role=value}
export function resetPreview(){db=initial();persist()}
function result(value){persist();return structuredClone(value??null)}
function find(list,name){const row=list.find(x=>x.name===name);if(!row)throw Error('This preview record is no longer available.');return row}
export async function previewRequest(module,method,args={}){
 args=JSON.parse(JSON.stringify(args));
 const v=args.data||args,member=own()
 if(module==='portal_session')return method==='current'?{authenticated:true,role:role==='Super Admin'?role:member.role,member:role==='Super Admin'?null:member,user:member.user}:{students:0,teachers:db.profiles.filter(p=>p.kind==='Teacher').length,institutes:db.profiles.filter(p=>p.kind==='Institute').length,pending_profiles:db.profiles.filter(p=>p.status==='Pending').length,pending_payouts:0}
 if(module==='api'){
  if(method==='bootstrap')return {institute:db.institute,member,mode:'interface-preview',lms_base:'/lms',username:member.user}
  if(method==='dashboard_summary')return {...blankMoney,classrooms:db.rooms.length}
  if(method==='classrooms')return db.rooms.filter(r=>!args.search||r.title.toLowerCase().includes(args.search.toLowerCase()))
  if(method==='schedule')return db.sessions
  if(['news','invoices','notifications'].includes(method))return db[method]
  if(method==='members')return []
  if(method==='teachers')return [roles.Teacher]
  if(method==='save_classroom'){
   const previous=db.rooms.find(r=>r.name===v.name),room={...v,name:previous?.name||id('class'),institute:db.institute.name,teacher:v.teacher||roles.Teacher.name,teacher_name:'Teacher preview',fee:0,active:1,students:0,access:{allowed:true,reason:'Interface preview'},font:v.font||'default'}
   if(previous)Object.assign(previous,room);else db.rooms.push(room);return result(room.name)
  }
  if(method==='classroom_detail'){const room=find(db.rooms,args.name);return {room,access:room.access,sessions:db.sessions.filter(s=>s.classroom===room.name),materials:[],feedback:[],announcements:[]}}
  if(method==='save_session'){const old=db.sessions.find(s=>s.name===v.name),row={...v,name:old?.name||id('session'),status:v.status||'Scheduled'};if(old)Object.assign(old,row);else db.sessions.push(row);return result(row.name)}
  if(method==='enrollments')return []
  if(method==='save_branding'){Object.assign(db.institute,v);return result({institute:db.institute,member})}
  if(method==='notification_preferences')return result({saved:true})
  if(method==='save_news'){db.news.push({...v,name:id('news'),creation:new Date().toISOString()});return result({saved:true})}
  if(method==='video_courses')return {courses:[],completions:[]}
 }
 if(module==='profiles'){
  if(method==='me')return {profile:db.profiles.find(p=>p.user===member.user)||null,phone_verified:true}
  if(method==='save_profile'){
   if(db.profiles.some(p=>p.username===v.username&&p.user!==member.user))throw Error('That username is already used in this preview.')
   let p=db.profiles.find(p=>p.user===member.user);if(!p){p={name:id('profile'),user:member.user};db.profiles.push(p)}Object.assign(p,v,{status:v.kind==='Student'?'Verified':'Pending',code:''});return result(p)
  }
  if(method==='pending')return db.profiles.filter(p=>p.status==='Pending')
  if(method==='search')return db.profiles.filter(p=>p.status==='Verified'&&p.kind!=='Student'&&(p.username+' '+p.display_name).toLowerCase().includes((args.query||'').toLowerCase().replace(/^@/,'')))
  if(method==='review'){const p=find(db.profiles,args.profile);p.status=args.decision;if(args.decision==='Verified')p.code='PREVIEW-'+p.name.slice(-4);return result(p)}
  if(method==='relationships')return {followers:db.links.filter(l=>l.profile===args.profile&&l.kind==='Follow'&&l.status==='Active').length,owns_profile:find(db.profiles,args.profile).user===member.user,relationships:db.links.filter(l=>l.profile===args.profile)}
  if(method==='relate'){const row={name:id('link'),profile:args.profile,user:member.user,kind:args.kind,status:args.kind==='Follow'?'Active':'Pending'};db.links.push(row);return result(row)}
  if(method==='change_relationship'){Object.assign(find(db.links,args.relationship),{status:args.status});return result({saved:true})}
  if(method==='followed_updates')return []
  if(method==='publish_update')return result({saved:true})
 }
 if(module==='owner_pricing'){
  if(method==='entitlements')return {'Study Space':true,'AI Papers':false,'To-do':false,Journal:false}
  if(method==='assignments')return db.assignments.filter(a=>a.active)
  if(method==='assign'){
   if(role!=='Super Admin')throw Error('Use the Super Admin preview to assign prices.')
   for(const a of db.assignments)if(a.customer===v.customer&&a.product===v.product)a.active=0
   const row={...v,name:id('price'),active:1};db.assignments.push(row);return result(row)
  }
  if(method==='quote'){
   const a=db.assignments.find(a=>a.active&&a.customer===member.user&&a.product===args.product)
   if(!a)throw Error('No price is assigned. In Super Admin → Pricing, use '+member.user+' to try an assignment.')
   const subtotal=Number(a.base_minor)+Math.max(0,1-Number(a.included_units))*Number(a.unit_minor),discount=Math.floor((subtotal*Number(a.discount_bps)+5000)/10000),tax=Math.floor(((subtotal-discount)*Number(a.tax_bps)+5000)/10000)
   return {name:id('quote'),product:a.product,currency:a.currency,period:a.period,expires_at:new Date(Date.now()+900000).toISOString(),breakdown:{subtotal_minor:subtotal,discount_minor:discount,tax_minor:tax,total_minor:subtotal-discount+tax},payment_available:false}
  }
  if(method==='classroom_price'){find(db.rooms,args.classroom).fee=Number(args.amount_minor)/100;return result({saved:true})}
  if(method==='grant'){db.grants.push({...args,name:id('grant')});return result({saved:true})}
 }
 if(module==='papers'){
  if(method==='listing')return db.papers.filter(p=>member.role!=='Student'||p.status==='Published')
  if(method==='detail')return find(db.papers,args.name)
  if(method==='draft'){
   if(!v.classroom||!v.title?.trim()||!v.questions?.length)throw Error('Create a classroom, title and questions first.')
   if(v.questions.some(q=>!q.prompt?.trim()||q.kind==='MCQ'&&q.options.some(o=>!o.trim())))throw Error('Fill in each question and its options.')
   const old=db.papers.find(p=>p.name===v.name),p={...v,name:old?.name||id('paper'),source:old?.source||'Manual',status:'Draft',max_marks:v.questions.reduce((s,q)=>s+Number(q.marks),0)}
   if(old)Object.assign(old,p);else db.papers.push(p);return result(p)
  }
  if(method==='publish'){find(db.papers,args.name).status='Published';return result({status:'Published'})}
  if(method==='archive'){find(db.papers,args.name).status='Archived';return result({status:'Archived'})}
  if(method==='submissions')return db.attempts.filter(a=>a.paper===args.paper)
  if(method==='start'){
   const p=find(db.papers,args.name);let a=db.attempts.find(a=>a.paper===p.name);if(!a){a={name:id('attempt'),paper:p.name,student:member.name,status:'Started',started_at:new Date().toISOString(),deadline:new Date(Date.now()+p.duration_minutes*60000).toISOString()};db.attempts.push(a)}
   if(a.status!=='Started')throw Error('This attempt has been submitted.')
   return result({attempt:a.name,deadline:a.deadline,server_time:new Date().toISOString(),questions:p.questions.map(q=>({...q,options:q.kind==='True/False'?['True','False']:q.options,answer:undefined}))})
  }
  if(method==='submit'){const a=find(db.attempts,args.attempt),p=find(db.papers,a.paper);a.answers=JSON.stringify(args.answers);a.score=p.questions.reduce((s,q,i)=>s+(q.kind!=='Written'&&Number(q.answer)===args.answers[i]?Number(q.marks):0),0);a.status=p.questions.some(q=>q.kind==='Written')?'Submitted':'Graded';return result({status:a.status,score:a.score})}
  if(method==='mark'){Object.assign(find(db.attempts,args.attempt),{score:args.score,feedback:args.feedback,status:'Graded'});return result({saved:true})}
  if(method==='generate')throw Error('AI generation requires the real server, an active entitlement and OpenAI configuration. This preview does not send prompts or spend API credits.')
 }
 if(module==='wallet'){
  if(method==='admin_queue')return {requests:[],methods:[]}
  if(method==='dashboard')return {wallet:{name:'preview-wallet',currency:'USD',country:'International',beneficiary:role==='Admin'?'Institute':'Teacher',available_minor:0,held_minor:0},minimum_minor:2000,methods:[],requests:[],ledger:[]}
 }
 if(module==='operations'){
  if(method==='attendance')return db.attendance
  if(method==='tickets')return db.tickets
  if(method==='thread')return db.replies.filter(r=>r.ticket===args.ticket)
  if(method==='create_ticket'){const t={...args,name:id('ticket'),requester:member.user,status:'Open'};db.tickets.push(t);db.replies.push({ticket:t.name,author_user:member.user,body:args.body,creation:new Date().toISOString()});return result(t)}
  if(method==='reply'){db.replies.push({...args,author_user:member.user,creation:new Date().toISOString()});if(args.status)find(db.tickets,args.ticket).status=args.status;return result({saved:true})}
 }
 if(module==='soul'&&method==='status')return {configured:false,enabled:false,available:false}
 if(['account','contact','calendar_sync','youtube'].includes(module))throw Error('This connected service requires a configured Frappe site. You can explore its controls here without sending data.')
 throw Error('This action needs the connected backend. Preview navigation does not send messages, collect payments or change real accounts.')
}
