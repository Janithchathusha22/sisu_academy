<script setup>
import {computed} from 'vue'
import SocialIcon from './SocialIcon.vue'
import {socialNetworks,providerSocials} from './socials.js'
const props=defineProps({profile:Object})
const links=computed(()=>providerSocials(props.profile?.kind,props.profile?.socials))
</script>
<template><nav v-if="Object.keys(links).length" class="provider-social-links" :aria-label="(profile.display_name||'Provider')+' social media'"><a v-for="(url,key) in links" :key="key" :href="url" :class="'social-'+key" target="_blank" rel="noopener noreferrer" :aria-label="(profile.display_name||'Provider')+' on '+socialNetworks[key]+' (opens in a new tab)'" :title="socialNetworks[key]+' · opens in a new tab'"><SocialIcon :network="key"/></a></nav></template>
<style>.provider-social-links{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.provider-social-links a{display:grid;place-items:center;width:42px;min-height:44px;border:1px solid var(--student-border,#e5d9ef);border-radius:13px;background:var(--student-card,#fff);box-shadow:0 3px 10px #5d437009;transition:transform .15s,box-shadow .15s}.provider-social-links svg{width:22px;height:22px}.provider-social-links .social-facebook{color:#1877f2}.provider-social-links .social-youtube{color:#e62117}.provider-social-links .social-linkedin{color:#0a66c2}.provider-social-links .social-instagram{color:#c13584}.provider-social-links .social-twitter,.provider-social-links .social-tiktok{color:var(--student-ink,#443650)}.provider-social-links a:hover{transform:translateY(-2px);box-shadow:0 5px 14px #76539120}.provider-social-links a:focus-visible{outline:3px solid var(--student-accent,#906aaf);outline-offset:3px}@media(prefers-reduced-motion:reduce){.provider-social-links a{transition:none}.provider-social-links a:hover{transform:none}}</style>
